from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .config import settings
from .routers import auth, rooms, students, allocations, dashboard

app = FastAPI(title="Hostel Management API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in settings.CORS_ORIGINS.split(",")],
    allow_credentials=True, allow_methods=["*"], allow_headers=["*"],
)

for r in (auth, rooms, students, allocations, dashboard):
    app.include_router(r.router)


@app.get("/", tags=["Health"])
def health():
    return {"status": "ok"}
