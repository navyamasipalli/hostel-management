from datetime import datetime
from decimal import Decimal
from pydantic import BaseModel, ConfigDict
from .models import RoomStatus, RoomType, Role, AllocStatus


class ORM(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: Role
    full_name: str


class UserOut(ORM):
    id: int
    username: str
    full_name: str
    role: Role


class StudentCreate(BaseModel):
    student_code: str
    name: str
    phone: str | None = None
    email: str | None = None


class StudentOut(ORM, StudentCreate):
    id: int


class RoomCreate(BaseModel):
    room_no: int
    floor: int
    room_type: RoomType
    monthly_fee: Decimal


class RoomOut(ORM):
    id: int
    room_no: int
    floor: int
    room_type: RoomType
    capacity: int
    monthly_fee: Decimal
    status: RoomStatus
    occupants: list[StudentOut] = []


class RoomStatusUpdate(BaseModel):
    status: RoomStatus  # only available / maintenance allowed manually


class AllocationCreate(BaseModel):
    room_id: int
    student_id: int


class AllocationOut(ORM):
    id: int
    room_id: int
    room_no: int
    student_id: int
    student_name: str
    student_code: str
    allocated_by_name: str
    allocated_at: datetime
    checkout_at: datetime | None
    status: AllocStatus
