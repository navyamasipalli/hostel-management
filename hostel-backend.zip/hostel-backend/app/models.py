import enum
from datetime import datetime
from decimal import Decimal
from sqlalchemy import ForeignKey, String, Enum, DateTime, Numeric, Boolean
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .database import Base


class Role(str, enum.Enum):
    admin = "admin"
    warden = "warden"


class RoomStatus(str, enum.Enum):
    available = "available"
    occupied = "occupied"
    maintenance = "maintenance"


class RoomType(str, enum.Enum):
    Single = "Single"
    Double = "Double"
    Triple = "Triple"


class AllocStatus(str, enum.Enum):
    active = "active"
    checked_out = "checked_out"


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(String(50), unique=True)
    full_name: Mapped[str] = mapped_column(String(100))
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[Role] = mapped_column(Enum(Role), default=Role.warden)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)


class Room(Base):
    __tablename__ = "rooms"
    id: Mapped[int] = mapped_column(primary_key=True)
    room_no: Mapped[int] = mapped_column(unique=True)
    floor: Mapped[int]
    room_type: Mapped[RoomType] = mapped_column(Enum(RoomType))
    capacity: Mapped[int]
    monthly_fee: Mapped[Decimal] = mapped_column(Numeric(10, 2))
    status: Mapped[RoomStatus] = mapped_column(Enum(RoomStatus), default=RoomStatus.available)
    allocations: Mapped[list["Allocation"]] = relationship(back_populates="room")

    @property
    def active_allocations(self):
        return [a for a in self.allocations if a.status == AllocStatus.active]


class Student(Base):
    __tablename__ = "students"
    id: Mapped[int] = mapped_column(primary_key=True)
    student_code: Mapped[str] = mapped_column(String(30), unique=True)
    name: Mapped[str] = mapped_column(String(100))
    phone: Mapped[str | None] = mapped_column(String(20), nullable=True)
    email: Mapped[str | None] = mapped_column(String(120), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)
    allocations: Mapped[list["Allocation"]] = relationship(back_populates="student")


class Allocation(Base):
    __tablename__ = "allocations"
    id: Mapped[int] = mapped_column(primary_key=True)
    room_id: Mapped[int] = mapped_column(ForeignKey("rooms.id"))
    student_id: Mapped[int] = mapped_column(ForeignKey("students.id"))
    allocated_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    allocated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)
    checkout_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    status: Mapped[AllocStatus] = mapped_column(Enum(AllocStatus), default=AllocStatus.active)
    room: Mapped[Room] = relationship(back_populates="allocations")
    student: Mapped[Student] = relationship(back_populates="allocations")
