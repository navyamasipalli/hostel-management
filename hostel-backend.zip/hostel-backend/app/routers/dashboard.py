from datetime import datetime, timedelta
from fastapi import APIRouter, Depends
from sqlalchemy import select, func
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import Room, RoomStatus, Allocation
from ..security import staff

router = APIRouter(prefix="/dashboard", tags=["Dashboard"], dependencies=[Depends(staff)])


def predict(db: Session, total_beds: int, occupied_beds: int, weeks: int = 6):
    """Simple trend model: average weekly net change in occupied beds over the
    last 8 weeks (check-ins minus checkouts), projected forward."""
    now = datetime.now()
    start = now - timedelta(weeks=8)
    ins = db.scalar(select(func.count()).where(Allocation.allocated_at >= start)) or 0
    outs = db.scalar(select(func.count()).where(Allocation.checkout_at >= start)) or 0
    weekly_net = (ins - outs) / 8
    samples = ins + outs
    pts, beds = [], float(occupied_beds)
    for w in range(weeks + 1):
        pct = max(0, min(100, round(beds / total_beds * 100))) if total_beds else 0
        pts.append({"label": "Today" if w == 0 else f"+{w}w", "occupancy_pct": pct})
        beds += weekly_net
    return {"points": pts, "weekly_net_change": round(weekly_net, 2),
            "confidence_pct": min(95, 50 + samples * 2)}


@router.get("/summary")
def summary(db: Session = Depends(get_db)):
    rooms = db.scalars(select(Room)).all()
    count = lambda s: sum(1 for r in rooms if r.status == s)
    floors = []
    for f in sorted({r.floor for r in rooms}):
        fr = [r for r in rooms if r.floor == f]
        floors.append({"floor": f, "total": len(fr),
                       "occupied": sum(r.status == RoomStatus.occupied for r in fr),
                       "available": sum(r.status == RoomStatus.available for r in fr),
                       "maintenance": sum(r.status == RoomStatus.maintenance for r in fr)})
    total_beds = sum(r.capacity for r in rooms if r.status != RoomStatus.maintenance)
    occ_beds = db.scalar(select(func.count()).where(Allocation.status == "active")) or 0
    return {
        "total_rooms": len(rooms),
        "occupied_rooms": count(RoomStatus.occupied),
        "available_rooms": count(RoomStatus.available),
        "maintenance_rooms": count(RoomStatus.maintenance),
        "floors": floors,
        "prediction": predict(db, total_beds, occ_beds),
    }
