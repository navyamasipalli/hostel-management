from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session, joinedload
from ..database import get_db
from ..models import Allocation, AllocStatus, Room, RoomStatus, Student, User, Role
from ..schemas import AllocationCreate, AllocationOut
from ..security import staff

router = APIRouter(prefix="/allocations", tags=["Allocations"])


def refresh_room_status(room: Room):
    if room.status == RoomStatus.maintenance:
        return
    room.status = (RoomStatus.occupied if len(room.active_allocations) >= room.capacity
                   else RoomStatus.available)


def to_out(a: Allocation, db: Session) -> AllocationOut:
    by = db.get(User, a.allocated_by)
    return AllocationOut(
        id=a.id, room_id=a.room_id, room_no=a.room.room_no, student_id=a.student_id,
        student_name=a.student.name, student_code=a.student.student_code,
        allocated_by_name=by.full_name if by else "-", allocated_at=a.allocated_at,
        checkout_at=a.checkout_at, status=a.status)


@router.post("", response_model=AllocationOut, status_code=201)
def allocate(data: AllocationCreate, db: Session = Depends(get_db), user: User = Depends(staff)):
    room = db.scalar(select(Room).where(Room.id == data.room_id).with_for_update())
    student = db.get(Student, data.student_id)
    if not room or not student:
        raise HTTPException(404, "Room or student not found")
    if room.status == RoomStatus.maintenance:
        raise HTTPException(400, "Room is under maintenance")
    if len(room.active_allocations) >= room.capacity:
        raise HTTPException(400, "Room is full")
    if db.scalar(select(Allocation).where(Allocation.student_id == student.id,
                                          Allocation.status == AllocStatus.active)):
        raise HTTPException(400, "Student already has an active room")
    a = Allocation(room_id=room.id, student_id=student.id, allocated_by=user.id)
    db.add(a)
    db.flush()
    db.refresh(room)
    refresh_room_status(room)
    db.commit()
    db.refresh(a)
    return to_out(a, db)


@router.post("/{alloc_id}/checkout", response_model=AllocationOut)
def checkout(alloc_id: int, db: Session = Depends(get_db), user: User = Depends(staff)):
    a = db.get(Allocation, alloc_id)
    if not a:
        raise HTTPException(404, "Allocation not found")
    if a.status == AllocStatus.checked_out:
        raise HTTPException(400, "Already checked out")
    a.status = AllocStatus.checked_out
    a.checkout_at = datetime.now()
    db.flush()
    db.refresh(a.room)
    refresh_room_status(a.room)
    db.commit()
    db.refresh(a)
    return to_out(a, db)


@router.get("", response_model=list[AllocationOut])
def list_allocations(status: AllocStatus | None = None, search: str | None = None,
                     db: Session = Depends(get_db), user: User = Depends(staff)):
    """Admin sees the full history; warden sees only active allocations."""
    q = (select(Allocation).options(joinedload(Allocation.room), joinedload(Allocation.student))
         .join(Student).join(Room).order_by(Allocation.allocated_at.desc()))
    if user.role != Role.admin:
        status = AllocStatus.active
    if status:
        q = q.where(Allocation.status == status)
    if search:
        like = f"%{search}%"
        q = q.where(Student.name.like(like) | Student.student_code.like(like) | Room.room_no.like(like))
    return [to_out(a, db) for a in db.scalars(q.limit(500)).unique().all()]


@router.get("/by-room/{room_id}", response_model=list[AllocationOut])
def room_history(room_id: int, db: Session = Depends(get_db), user: User = Depends(staff)):
    q = (select(Allocation).options(joinedload(Allocation.room), joinedload(Allocation.student))
         .where(Allocation.room_id == room_id).order_by(Allocation.allocated_at.desc()))
    return [to_out(a, db) for a in db.scalars(q).unique().all()]
