from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select, or_
from sqlalchemy.orm import Session, selectinload
from ..database import get_db
from ..models import Room, RoomStatus, Student, Allocation, AllocStatus
from ..schemas import RoomOut, RoomCreate, RoomStatusUpdate
from ..security import staff, admin_only

router = APIRouter(prefix="/rooms", tags=["Rooms"])
CAP = {"Single": 1, "Double": 2, "Triple": 3}


def to_out(r: Room) -> RoomOut:
    out = RoomOut.model_validate(r)
    out.occupants = [a.student for a in r.active_allocations]
    return out


def load_opts():
    return selectinload(Room.allocations).selectinload(Allocation.student)


@router.get("", response_model=list[RoomOut], dependencies=[Depends(staff)])
def list_rooms(search: str | None = None, floor: int | None = None,
               status: RoomStatus | None = None, room_type: str | None = None,
               db: Session = Depends(get_db)):
    q = select(Room).options(load_opts()).order_by(Room.room_no)
    if floor:
        q = q.where(Room.floor == floor)
    if status:
        q = q.where(Room.status == status)
    if room_type:
        q = q.where(Room.room_type == room_type)
    if search:
        like = f"%{search}%"
        sub = (select(Allocation.room_id).join(Student)
               .where(Allocation.status == AllocStatus.active, Student.name.like(like)))
        q = q.where(or_(Room.room_no.like(like), Room.id.in_(sub)))
    return [to_out(r) for r in db.scalars(q).all()]


@router.get("/{room_id}", response_model=RoomOut, dependencies=[Depends(staff)])
def get_room(room_id: int, db: Session = Depends(get_db)):
    r = db.scalar(select(Room).options(load_opts()).where(Room.id == room_id))
    if not r:
        raise HTTPException(404, "Room not found")
    return to_out(r)


@router.post("", response_model=RoomOut, status_code=201, dependencies=[Depends(admin_only)])
def create_room(data: RoomCreate, db: Session = Depends(get_db)):
    if db.scalar(select(Room).where(Room.room_no == data.room_no)):
        raise HTTPException(409, "Room number already exists")
    r = Room(**data.model_dump(), capacity=CAP[data.room_type.value])
    db.add(r)
    db.commit()
    db.refresh(r)
    return to_out(r)


@router.patch("/{room_id}/status", response_model=RoomOut, dependencies=[Depends(admin_only)])
def set_status(room_id: int, data: RoomStatusUpdate, db: Session = Depends(get_db)):
    r = db.scalar(select(Room).options(load_opts()).where(Room.id == room_id))
    if not r:
        raise HTTPException(404, "Room not found")
    if data.status == RoomStatus.occupied:
        raise HTTPException(400, "Occupied status is set automatically by allocation")
    if r.active_allocations:
        raise HTTPException(400, "Check out all students before changing room status")
    r.status = data.status
    db.commit()
    db.refresh(r)
    return to_out(r)
