from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import Student
from ..schemas import StudentCreate, StudentOut
from ..security import staff

router = APIRouter(prefix="/students", tags=["Students"], dependencies=[Depends(staff)])


@router.get("", response_model=list[StudentOut])
def list_students(search: str | None = None, db: Session = Depends(get_db)):
    q = select(Student).order_by(Student.name)
    if search:
        q = q.where(Student.name.like(f"%{search}%") | Student.student_code.like(f"%{search}%"))
    return db.scalars(q.limit(200)).all()


@router.post("", response_model=StudentOut, status_code=201)
def create_student(data: StudentCreate, db: Session = Depends(get_db)):
    if db.scalar(select(Student).where(Student.student_code == data.student_code)):
        raise HTTPException(409, "Student code already exists")
    s = Student(**data.model_dump())
    db.add(s)
    db.commit()
    db.refresh(s)
    return s
