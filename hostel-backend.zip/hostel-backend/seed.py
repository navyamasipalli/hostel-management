"""Run once: python seed.py  -> creates tables, users, 40 rooms and demo students."""
import random
from app.database import Base, engine, SessionLocal
from app.models import User, Role, Room, RoomType, Student
from app.security import hash_password

Base.metadata.create_all(engine)
db = SessionLocal()

if not db.query(User).first():
    db.add_all([
        User(username="admin", full_name="Hostel Admin", role=Role.admin, password_hash=hash_password("admin123")),
        User(username="warden", full_name="Hostel Warden", role=Role.warden, password_hash=hash_password("warden123")),
    ])
if not db.query(Room).first():
    caps = {"Single": 1, "Double": 2, "Triple": 3}
    fees = {"Single": 6500, "Double": 5000, "Triple": 4000}
    random.seed(1)
    for f in range(1, 5):
        for n in range(1, 11):
            t = random.choice(list(caps))
            db.add(Room(room_no=f * 100 + n, floor=f, room_type=RoomType(t), capacity=caps[t], monthly_fee=fees[t]))
if not db.query(Student).first():
    for i, name in enumerate(["Arjun Reddy", "Karthik N", "Rahul Verma", "Sai Teja", "Mohan Das",
                              "Vikram S", "Naveen K", "Harish B", "Ravi Kumar", "Manoj P"], 1):
        db.add(Student(student_code=f"STU{i:03d}", name=name, phone=f"98765000{i:02d}"))
db.commit()
print("Seeded. Logins -> admin/admin123, warden/warden123")
