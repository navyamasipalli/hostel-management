-- Run this in MySQL Workbench (File > Open SQL Script > Run)
CREATE DATABASE IF NOT EXISTS hostel_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE hostel_db;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  full_name VARCHAR(100) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','warden') NOT NULL DEFAULT 'warden',
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS rooms (
  id INT AUTO_INCREMENT PRIMARY KEY,
  room_no INT NOT NULL UNIQUE,
  floor INT NOT NULL,
  room_type ENUM('Single','Double','Triple') NOT NULL,
  capacity INT NOT NULL,
  monthly_fee DECIMAL(10,2) NOT NULL,
  status ENUM('available','occupied','maintenance') NOT NULL DEFAULT 'available',
  INDEX idx_rooms_floor (floor),
  INDEX idx_rooms_status (status)
);

CREATE TABLE IF NOT EXISTS students (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_code VARCHAR(30) NOT NULL UNIQUE,
  name VARCHAR(100) NOT NULL,
  phone VARCHAR(20),
  email VARCHAR(120),
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_students_name (name)
);

-- "Allocations" are the booking/order records the admin can view
CREATE TABLE IF NOT EXISTS allocations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  room_id INT NOT NULL,
  student_id INT NOT NULL,
  allocated_by INT NOT NULL,
  allocated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  checkout_at DATETIME NULL,
  status ENUM('active','checked_out') NOT NULL DEFAULT 'active',
  FOREIGN KEY (room_id) REFERENCES rooms(id),
  FOREIGN KEY (student_id) REFERENCES students(id),
  FOREIGN KEY (allocated_by) REFERENCES users(id),
  INDEX idx_alloc_status (status)
);
