# Hostel Management – FastAPI + MySQL backend

## Setup
1. MySQL Workbench: open and run `schema.sql` (creates `hostel_db` and tables).
2. `cp .env.example .env` and put your MySQL password in it.
3. `python -m venv venv && source venv/bin/activate` (Windows: `venv\Scripts\activate`)
4. `pip install -r requirements.txt`
5. `python seed.py`   (admin/admin123, warden/warden123, 40 rooms, 10 students)
6. `uvicorn app.main:app --reload`  -> docs at http://127.0.0.1:8000/docs

## Roles
- admin: everything, incl. full allocation history, room create, maintenance toggle
- warden: view rooms, allocate, checkout, active allocations only

## Endpoints
POST /auth/login | GET /auth/me
GET /dashboard/summary  (cards + floor chart + AI prediction)
GET /rooms?search=&floor=&status=&room_type= | GET /rooms/{id} | POST /rooms | PATCH /rooms/{id}/status
GET/POST /students
POST /allocations | POST /allocations/{id}/checkout | GET /allocations | GET /allocations/by-room/{room_id}

## React client (src/api.js)
```js
import axios from "axios";
const api = axios.create({ baseURL: "http://127.0.0.1:8000" });
api.interceptors.request.use(c => {
  const t = localStorage.getItem("token");
  if (t) c.headers.Authorization = `Bearer ${t}`;
  return c;
});
export const login = async (username, password) => {
  const body = new URLSearchParams({ username, password });
  const { data } = await api.post("/auth/login", body);
  localStorage.setItem("token", data.access_token);
  return data; // { role, full_name }
};
export const getSummary = () => api.get("/dashboard/summary").then(r => r.data);
export const getRooms = params => api.get("/rooms", { params }).then(r => r.data);
export const allocate = (room_id, student_id) => api.post("/allocations", { room_id, student_id });
export const checkout = id => api.post(`/allocations/${id}/checkout`);
export const getAllocations = params => api.get("/allocations", { params }).then(r => r.data);
export const setRoomStatus = (id, status) => api.patch(`/rooms/${id}/status`, { status });
export default api;
```
